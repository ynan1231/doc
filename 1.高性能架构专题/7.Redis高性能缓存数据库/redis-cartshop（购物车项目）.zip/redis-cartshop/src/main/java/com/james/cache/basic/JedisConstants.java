package com.james.cache.basic;

public class JedisConstants {
	public static String ip = "192.168.42.111";
	public static int port = 6379;
	public static String auth = "12345678";
}
