package cn.enjoy.listener;

/**
 * Created by VULCAN on 2018/10/12.
 */
public class ElectionMaster {
    public static boolean isSurvival;
}
