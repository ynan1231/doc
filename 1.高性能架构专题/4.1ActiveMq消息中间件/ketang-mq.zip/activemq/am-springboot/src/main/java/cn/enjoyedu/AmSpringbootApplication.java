package cn.enjoyedu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmSpringbootApplication {

    public static void main(String[] args) {
        SpringApplication.run(AmSpringbootApplication.class, args);
    }
}
