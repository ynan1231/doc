package com.xx.jack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomSpringBootStarterAutoconfigurerApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomSpringBootStarterAutoconfigurerApplication.class, args);
    }

}
