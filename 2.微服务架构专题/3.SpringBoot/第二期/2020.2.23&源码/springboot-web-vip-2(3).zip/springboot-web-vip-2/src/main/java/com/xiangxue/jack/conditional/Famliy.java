package com.xiangxue.jack.conditional;

public interface Famliy {

    void setPeople(People people);
}
