package com.xiangxue.jack.redisRepositories;

import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.stereotype.Component;

@Component
@EnableRedisRepositories
public class RedisRepositoriesConfig {
}
