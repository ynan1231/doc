package com.xiangxue.jack.conditional;

public interface People {
    String eat();
}
