package com.xiangxue.jack.conditional;

public class JackFamliy implements Famliy {

    private People people;

    @Override
    public void setPeople(People people) {
        this.people = people;
    }
}
