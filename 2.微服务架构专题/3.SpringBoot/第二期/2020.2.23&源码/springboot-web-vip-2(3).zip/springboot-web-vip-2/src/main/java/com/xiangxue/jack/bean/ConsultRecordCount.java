package com.xiangxue.jack.bean;

public class ConsultRecordCount {
    
    public String psptId;
    
    public Integer isproduce;
    
    public Integer unproduce;
    
    public String getPsptId() {
        return psptId;
    }
    
    public void setPsptId(String psptId) {
        this.psptId = psptId;
    }
    
    public Integer getIsproduce() {
        return isproduce;
    }
    
    public void setIsproduce(Integer isproduce) {
        this.isproduce = isproduce;
    }
    
    public Integer getUnproduce() {
        return unproduce;
    }
    
    public void setUnproduce(Integer unproduce) {
        this.unproduce = unproduce;
    }
}
