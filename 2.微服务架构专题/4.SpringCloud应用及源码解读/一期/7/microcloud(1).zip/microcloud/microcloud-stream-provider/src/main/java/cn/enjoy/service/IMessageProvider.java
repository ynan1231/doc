package cn.enjoy.service;
import cn.enjoy.vo.Product;
public interface IMessageProvider {
     void send(Product product);
}