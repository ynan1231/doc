This sample uses the official demo provided by Apollo, visit [here](http://106.12.25.204:8070/config.html?#/appid=dubbo-configcenter-apollo) to see the detailed configurations.
