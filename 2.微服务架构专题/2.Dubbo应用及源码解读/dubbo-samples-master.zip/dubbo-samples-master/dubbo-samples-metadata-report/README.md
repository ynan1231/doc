
How to run applicaton ?

1. Run ZkClean to clean zookeeper configuration.
2. Run XXProvider, there is some log in console
3. Run XXConsumer, there is some log in console

