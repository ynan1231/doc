package com.nacos.consume.service;

import com.nacos.consume.feign.IndexService;
import io.seata.spring.annotation.GlobalTransactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    IndexService indexService;


    @GlobalTransactional
    public String update(String name) {
        String str = indexService.index();
        if(name.equals("zl"))
            System.out.println("xxxxxxxxxxxx"+1/0);
        return str;
    }
}
