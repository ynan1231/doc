package com.nacos.consume.service;

import io.seata.spring.annotation.GlobalTransactional;
import org.springframework.stereotype.Service;

public interface ProductService {

    public String update(String name);
}
