package com.nacos.consume.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("provide")
public interface IndexService {
    @GetMapping("/index")
    public String index();
}
