package com.nacos.consume.web;

import com.nacos.consume.feign.IndexService;
import com.nacos.consume.service.ProductService;
import io.seata.spring.annotation.GlobalTransactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
public class IndexController {


    @Autowired
    ProductService productService;


    @GetMapping("index")

    public String index(@RequestParam String name){
        String result =  productService.update(name);
        if(name.equals("zcc"))
            System.out.println("xxxxxxxxxxxx"+1/0);
        return result;
    }


}
