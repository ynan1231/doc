本工程展示了，如何通过Netty内置的ChannelHandler
1、实现一个Http服务器
2、增加压缩支持
3、Https支持
4、除浏览器访问外，还可以用Netty实现Http客户端

