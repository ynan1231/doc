/**
 * @author Mark老师   享学课堂 https://enjoy.ke.qq.com
 * 往期课程和VIP课程咨询 依娜老师  QQ：2133576719
 * 类说明：
 * UDP的广播实现，将日志信息在全网广播
 * bcside包下为发送端，acceptside为接收端
 */
package cn.enjoyedu.broadcast;